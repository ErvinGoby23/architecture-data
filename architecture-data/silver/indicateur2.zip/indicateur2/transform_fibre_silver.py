"""
transform_fibre_silver.py — Pipeline Silver · Indicateur 2 : Fibre
Urban Data Explorer

Source  : brute/Score-de-connectivite/indicateur-wifi.csv  (ARCEP, T4 2017→T4 2025)
Output  : nettoyage-indicateur2/fibre_paris_silver.parquet
"""

import pandas as pd
import os
import sys
from datetime import datetime
date_str = sys.argv[1] if len(sys.argv) > 1 else datetime.now().strftime('%Y-%m-%d')

BRONZE_FILE = '../../brute/Score-de-connectivite/indicateur-wifi.csv'
SILVER_DIR = os.path.join('nettoyage-indicateur2', date_str)

os.makedirs(SILVER_DIR, exist_ok=True)

# Chargement
# Lecture du CSV ARCEP, en sautant les 4 lignes d'en-tête du fichier source
df = pd.read_csv(
    BRONZE_FILE,
    sep=None,
    engine='python',
    header=4,
    encoding='utf-8-sig'
)
df.columns = df.columns.str.strip().str.replace('\ufeff', '', regex=False)
print(f'[1/5] Chargement OK — shape brut : {df.shape}')
print("Colonnes disponibles :", df.columns.tolist())

# Filtrage Paris
# Ne garde que les arrondissements parisiens (codes 75101 à 75120)
df = df[df['Code arrondissement'].between(75101, 75120)].copy()
print(f'[2/5] Filtrage Paris — lignes retenues : {len(df)} (attendu : 20)')

# Nettoyage vectorisé — toutes les colonnes numériques
# Colonnes T4 annuelles uniquement (T4 = fin d'année, valeur représentative)
COLS_T4_ANNUELLES = [f'T4 {y}' for y in range(2017, 2026) if f'T4 {y}' in df.columns]

cols_numeriques = (
    ['Logements', 'Établissements', 'Meilleure estimation des locaux T4 2025'] +
    [c for c in df.columns if c.startswith('T')]
)

# Nettoie les espaces insécables des nombres avant conversion en numérique
clean_numeric = lambda s: pd.to_numeric(
    s.astype(str)
     .str.replace('\u202f', '', regex=False)
     .str.replace('\xa0',   '', regex=False)
     .str.replace(' ',      '', regex=False)
     .str.strip(),
    errors='coerce'
)

for col in cols_numeriques:
    if col in df.columns:
        df[col] = clean_numeric(df[col])

print(f'[3/5] Nettoyage OK')

# code_postal recalculé depuis le format ARCEP (751XX)
df['code_postal'] = df['Code arrondissement'] - 75100 + 75000

# Melt — une ligne par (code_postal, annee)
# Transforme les colonnes T4 2017...T4 2025 en lignes avec colonne annee
df_melt = df[['code_postal', 'Code arrondissement', 'Nom arrondissement',
              'Logements', 'Établissements',
              'Meilleure estimation des locaux T4 2025'] + COLS_T4_ANNUELLES].melt(
    id_vars=['code_postal', 'Code arrondissement', 'Nom arrondissement',
             'Logements', 'Établissements', 'Meilleure estimation des locaux T4 2025'],
    value_vars=COLS_T4_ANNUELLES,
    var_name='trimestre',
    value_name='locaux_fibres'
)

# Extrait l'année depuis le nom de colonne "T4 YYYY"
df_melt['annee'] = df_melt['trimestre'].str.extract(r'(\d{4})').astype(int)
df_melt = df_melt.drop(columns=['trimestre'])

df_silver = df_melt.rename(columns={
    'Code arrondissement': 'code_arrondissement',
    'Nom arrondissement':  'nom_arrondissement',
    'Logements':           'nb_logements',
    'Établissements':      'nb_etablissements',
    'Meilleure estimation des locaux T4 2025': 'locaux_total',
})

df_silver = df_silver.sort_values(['code_postal', 'annee']).reset_index(drop=True)
print(f'[4/5] Table silver construite — shape : {df_silver.shape}')
print(f'      Années disponibles : {sorted(df_silver["annee"].unique())}')
print(f'      PK : (code_postal, annee) — {df_silver[["code_postal","annee"]].nunique()} combinaisons uniques')

# Export Parquet
parquet_path = os.path.join(SILVER_DIR, 'fibre_paris_silver.parquet')
df_silver.to_parquet(parquet_path, index=False)
print(f'[5/5] Parquet créé : {parquet_path}')

print('\n=== SILVER fibre OK ===')
print(df_silver.head(20).to_string(index=False))